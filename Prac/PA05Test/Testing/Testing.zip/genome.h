#ifndef PA05_H
#define PA05_H

int * Longest_conserved_gene_sequence(char *filename, int *size_of_seq);

#endif
